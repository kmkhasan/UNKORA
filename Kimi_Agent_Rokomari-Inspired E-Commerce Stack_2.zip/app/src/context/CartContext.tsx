import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { CartItem } from '../data/mockDatabase';
import { cartAPI } from '../api/apiService';
import { toast } from 'sonner';

interface CartContextType {
  items: CartItem[];
  isLoading: boolean;
  addItem: (productId: string, quantity?: number, variantId?: string) => Promise<void>;
  updateItem: (cartItemId: string, quantity: number) => Promise<void>;
  removeItem: (cartItemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  applyCoupon: (code: string) => Promise<{ discount: number; message: string }>;
  totalItems: number;
  subtotal: number;
  discount: number;
  tax: number;
  shipping: number;
  total: number;
  couponCode: string | null;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [discount, setDiscount] = useState(0);
  const [couponCode, setCouponCode] = useState<string | null>(null);

  // Load cart on mount
  useEffect(() => {
    const loadCart = async () => {
      try {
        const cartItems = await cartAPI.get();
        setItems(cartItems);
      } catch (error) {
        console.error('Failed to load cart:', error);
      }
    };
    loadCart();
  }, []);

  const addItem = useCallback(async (productId: string, quantity = 1, variantId?: string) => {
    setIsLoading(true);
    try {
      const updatedCart = await cartAPI.addItem(productId, quantity, variantId);
      setItems(updatedCart);
      toast.success('Added to cart!');
    } catch (error) {
      toast.error('Failed to add item');
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateItem = useCallback(async (cartItemId: string, quantity: number) => {
    setIsLoading(true);
    try {
      const updatedCart = await cartAPI.updateItem(cartItemId, quantity);
      setItems(updatedCart);
    } catch (error) {
      toast.error('Failed to update item');
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const removeItem = useCallback(async (cartItemId: string) => {
    setIsLoading(true);
    try {
      const updatedCart = await cartAPI.removeItem(cartItemId);
      setItems(updatedCart);
      toast.success('Removed from cart');
    } catch (error) {
      toast.error('Failed to remove item');
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearCart = useCallback(async () => {
    setIsLoading(true);
    try {
      await cartAPI.clear();
      setItems([]);
      setDiscount(0);
      setCouponCode(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const applyCoupon = useCallback(async (code: string) => {
    try {
      const result = await cartAPI.applyCoupon(code);
      setDiscount(result.discount);
      setCouponCode(code);
      toast.success(result.message);
      return result;
    } catch (error: any) {
      toast.error(error.message || 'Invalid coupon');
      throw error;
    }
  }, []);

  // Calculate totals
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => {
    const price = item.variant?.price || item.product.price;
    return sum + price * item.quantity;
  }, 0);
  const tax = subtotal * 0.08;
  const shipping = subtotal > 50 ? 0 : 9.99;
  const total = subtotal + tax + shipping - discount;

  return (
    <CartContext.Provider
      value={{
        items,
        isLoading,
        addItem,
        updateItem,
        removeItem,
        clearCart,
        applyCoupon,
        totalItems,
        subtotal,
        discount,
        tax,
        shipping,
        total,
        couponCode,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
