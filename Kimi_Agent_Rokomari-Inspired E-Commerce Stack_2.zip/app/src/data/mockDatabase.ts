// Mock Database - This can be replaced with real backend API calls

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatar?: string;
  role: 'user' | 'admin';
  addresses: Address[];
  createdAt: string;
}

export interface Address {
  id: string;
  type: 'shipping' | 'billing';
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  parentId?: string;
  productCount: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  price: number;
  comparePrice?: number;
  sku: string;
  inventory: number;
  categoryId: string;
  category: string;
  images: string[];
  attributes: Record<string, string>;
  variants?: ProductVariant[];
  rating: number;
  reviewCount: number;
  tags: string[];
  isFeatured: boolean;
  isNew: boolean;
  discount?: number;
  createdAt: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  sku: string;
  price: number;
  inventory: number;
  attributes: Record<string, string>;
  image?: string;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  title: string;
  content: string;
  images?: string[];
  helpfulCount: number;
  verified: boolean;
  createdAt: string;
}

export interface CartItem {
  id: string;
  productId: string;
  variantId?: string;
  quantity: number;
  product: Product;
  variant?: ProductVariant;
}

export interface Order {
  id: string;
  userId: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: OrderItem[];
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
  shippingAddress: Address;
  billingAddress: Address;
  paymentMethod: string;
  tracking?: OrderTracking;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  variantId?: string;
  name: string;
  image: string;
  quantity: number;
  price: number;
}

export interface OrderTracking {
  carrier: string;
  trackingNumber: string;
  events: TrackingEvent[];
}

export interface TrackingEvent {
  status: string;
  location: string;
  timestamp: string;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrder?: number;
  maxUses: number;
  usedCount: number;
  expiresAt: string;
}

// Mock Data
export const categories: Category[] = [
  {
    id: 'cat-1',
    name: 'Fiction',
    slug: 'fiction',
    description: 'Explore imaginary worlds and captivating stories',
    image: '/images/categories/fiction.jpg',
    productCount: 1250,
  },
  {
    id: 'cat-2',
    name: 'Non-Fiction',
    slug: 'non-fiction',
    description: 'Real stories, knowledge, and insights',
    image: '/images/categories/non-fiction.jpg',
    productCount: 890,
  },
  {
    id: 'cat-3',
    name: 'Children\'s Books',
    slug: 'children',
    description: 'Magical stories for young readers',
    image: '/images/categories/children.jpg',
    productCount: 650,
  },
  {
    id: 'cat-4',
    name: 'Academic',
    slug: 'academic',
    description: 'Educational resources and textbooks',
    image: '/images/categories/academic.jpg',
    productCount: 2100,
  },
  {
    id: 'cat-5',
    name: 'Baby Products',
    slug: 'baby',
    description: 'Gentle care for your little ones',
    image: '/images/baby/baby-1.jpg',
    productCount: 340,
  },
  {
    id: 'cat-6',
    name: 'Leather Goods',
    slug: 'leather',
    description: 'Premium handcrafted leather products',
    image: '/images/leather/leather-1.jpg',
    productCount: 180,
  },
];

export const products: Product[] = [
  // Books
  {
    id: 'prod-1',
    name: 'The Chronicles of Aetheria',
    slug: 'chronicles-of-aetheria',
    description: 'Embark on an epic fantasy journey through the mystical realm of Aetheria. This bestselling novel weaves together magic, adventure, and unforgettable characters in a world where dreams and reality intertwine.',
    shortDescription: 'Epic fantasy adventure in a mystical realm',
    price: 24.99,
    comparePrice: 34.99,
    sku: 'BK-AET-001',
    inventory: 45,
    categoryId: 'cat-1',
    category: 'Fiction',
    images: ['/images/books/book-1.jpg'],
    attributes: { format: 'Hardcover', pages: '452', language: 'English' },
    rating: 4.8,
    reviewCount: 128,
    tags: ['bestseller', 'fantasy', 'new'],
    isFeatured: true,
    isNew: true,
    discount: 29,
    createdAt: '2024-01-15',
  },
  {
    id: 'prod-2',
    name: 'Great Expectations',
    slug: 'great-expectations',
    description: 'Charles Dickens\' timeless classic follows the journey of Pip, an orphan who rises from humble beginnings to become a gentleman, exploring themes of ambition, love, and social class.',
    shortDescription: 'Timeless classic by Charles Dickens',
    price: 18.99,
    sku: 'BK-GE-002',
    inventory: 120,
    categoryId: 'cat-1',
    category: 'Classic',
    images: ['/images/books/book-2.jpg'],
    attributes: { format: 'Hardcover', pages: '544', language: 'English' },
    rating: 4.9,
    reviewCount: 892,
    tags: ['classic', 'literature'],
    isFeatured: true,
    isNew: false,
    createdAt: '2023-06-10',
  },
  {
    id: 'prod-3',
    name: 'The Silent Echoes',
    slug: 'silent-echoes',
    description: 'A gripping mystery thriller that will keep you on the edge of your seat. Detective Sarah Chen unravels a decades-old cold case with shocking connections to her own past.',
    shortDescription: 'Gripping mystery thriller',
    price: 22.99,
    comparePrice: 28.99,
    sku: 'BK-SE-003',
    inventory: 32,
    categoryId: 'cat-1',
    category: 'Mystery',
    images: ['/images/books/book-3.jpg'],
    attributes: { format: 'Paperback', pages: '368', language: 'English' },
    rating: 4.6,
    reviewCount: 67,
    tags: ['mystery', 'thriller'],
    isFeatured: false,
    isNew: true,
    createdAt: '2024-02-01',
  },
  {
    id: 'prod-4',
    name: 'The Silent Anomaly',
    slug: 'silent-anomaly',
    description: 'In a world where silence is deadly, one woman discovers a secret that could save humanity—or destroy it. A psychological thriller that challenges perception and reality.',
    shortDescription: 'Psychological thriller',
    price: 19.99,
    sku: 'BK-SA-004',
    inventory: 78,
    categoryId: 'cat-1',
    category: 'Thriller',
    images: ['/images/books/book-4.jpg'],
    attributes: { format: 'Hardcover', pages: '416', language: 'English' },
    rating: 4.7,
    reviewCount: 156,
    tags: ['thriller', 'suspense'],
    isFeatured: true,
    isNew: false,
    createdAt: '2023-09-20',
  },
  {
    id: 'prod-5',
    name: 'Whispered Dreams',
    slug: 'whispered-dreams',
    description: 'A heartwarming romance about second chances and the power of love to heal old wounds. Emma and James must confront their past to build a future together.',
    shortDescription: 'Heartwarming romance novel',
    price: 16.99,
    comparePrice: 21.99,
    sku: 'BK-WD-005',
    inventory: 56,
    categoryId: 'cat-1',
    category: 'Romance',
    images: ['/images/books/book-5.jpg'],
    attributes: { format: 'Paperback', pages: '312', language: 'English' },
    rating: 4.5,
    reviewCount: 234,
    tags: ['romance', 'bestseller'],
    isFeatured: false,
    isNew: false,
    createdAt: '2023-11-05',
  },
  {
    id: 'prod-6',
    name: 'Neo-Genesis',
    slug: 'neo-genesis',
    description: 'Set in a distant future where humanity has colonized the stars, Neo-Genesis explores the ethical dilemmas of artificial intelligence and what it means to be human.',
    shortDescription: 'Science fiction epic',
    price: 27.99,
    sku: 'BK-NG-006',
    inventory: 41,
    categoryId: 'cat-1',
    category: 'Sci-Fi',
    images: ['/images/books/book-6.jpg'],
    attributes: { format: 'Hardcover', pages: '528', language: 'English' },
    rating: 4.8,
    reviewCount: 89,
    tags: ['sci-fi', 'award-winner'],
    isFeatured: true,
    isNew: true,
    createdAt: '2024-01-20',
  },
  // Baby Products
  {
    id: 'prod-101',
    name: 'Cute Animal Onesie',
    slug: 'cute-animal-onesie',
    description: 'Adorable onesie featuring cute animal prints. Made from 100% organic cotton, soft and gentle on baby\'s delicate skin. Perfect for everyday wear or special occasions.',
    shortDescription: 'Organic cotton onesie with animal prints',
    price: 14.99,
    comparePrice: 19.99,
    sku: 'BB-ON-001',
    inventory: 150,
    categoryId: 'cat-5',
    category: 'Baby Clothing',
    images: ['/images/baby/baby-1.jpg'],
    attributes: { material: 'Organic Cotton', sizes: '0-3M, 3-6M, 6-12M', care: 'Machine washable' },
    variants: [
      { id: 'var-101-1', name: '0-3 Months', sku: 'BB-ON-001-S', price: 14.99, inventory: 50, attributes: { size: '0-3M' } },
      { id: 'var-101-2', name: '3-6 Months', sku: 'BB-ON-001-M', price: 14.99, inventory: 60, attributes: { size: '3-6M' } },
      { id: 'var-101-3', name: '6-12 Months', sku: 'BB-ON-001-L', price: 14.99, inventory: 40, attributes: { size: '6-12M' } },
    ],
    rating: 4.9,
    reviewCount: 312,
    tags: ['organic', 'clothing', 'bestseller'],
    isFeatured: true,
    isNew: false,
    createdAt: '2023-08-15',
  },
  {
    id: 'prod-102',
    name: 'Soft Plush Teddy Bear',
    slug: 'soft-plush-teddy-bear',
    description: 'Ultra-soft teddy bear that becomes baby\'s best friend. Made with hypoallergenic materials and premium plush fabric. Perfect for cuddling and comfort.',
    shortDescription: 'Ultra-soft hypoallergenic teddy bear',
    price: 24.99,
    sku: 'BB-TB-002',
    inventory: 89,
    categoryId: 'cat-5',
    category: 'Toys',
    images: ['/images/baby/baby-2.jpg'],
    attributes: { material: 'Hypoallergenic Plush', height: '12 inches', care: 'Surface clean' },
    rating: 4.8,
    reviewCount: 456,
    tags: ['toys', 'plush', 'gift'],
    isFeatured: true,
    isNew: false,
    createdAt: '2023-05-20',
  },
  {
    id: 'prod-103',
    name: 'Colorful Baby Rattle',
    slug: 'colorful-baby-rattle',
    description: 'Bright and engaging rattle designed to stimulate baby\'s senses. Features multiple textures, colors, and sounds to encourage sensory development.',
    shortDescription: 'Sensory development rattle',
    price: 9.99,
    comparePrice: 12.99,
    sku: 'BB-RT-003',
    inventory: 200,
    categoryId: 'cat-5',
    category: 'Toys',
    images: ['/images/baby/baby-3.jpg'],
    attributes: { material: 'BPA-free Plastic', age: '0+ months', care: 'Washable' },
    rating: 4.7,
    reviewCount: 178,
    tags: ['toys', 'development', 'sale'],
    isFeatured: false,
    isNew: true,
    createdAt: '2024-01-10',
  },
  {
    id: 'prod-104',
    name: 'Soft Baby Blanket',
    slug: 'soft-baby-blanket',
    description: 'Luxuriously soft blanket perfect for swaddling, nursing, or stroller use. Made from premium fleece that gets softer with every wash.',
    shortDescription: 'Premium soft fleece blanket',
    price: 29.99,
    sku: 'BB-BL-004',
    inventory: 67,
    categoryId: 'cat-5',
    category: 'Essentials',
    images: ['/images/baby/baby-4.jpg'],
    attributes: { material: 'Premium Fleece', size: '30x40 inches', care: 'Machine washable' },
    rating: 4.9,
    reviewCount: 289,
    tags: ['essentials', 'blanket', 'gift'],
    isFeatured: true,
    isNew: false,
    createdAt: '2023-07-12',
  },
  // Leather Products
  {
    id: 'prod-201',
    name: 'Premium Leather Wallet',
    slug: 'premium-leather-wallet',
    description: 'Handcrafted from full-grain Italian leather, this wallet combines timeless elegance with modern functionality. Features multiple card slots, bill compartments, and RFID protection.',
    shortDescription: 'Full-grain Italian leather wallet',
    price: 49.99,
    comparePrice: 69.99,
    sku: 'LG-WL-001',
    inventory: 45,
    categoryId: 'cat-6',
    category: 'Accessories',
    images: ['/images/leather/leather-1.jpg'],
    attributes: { material: 'Full-grain Leather', dimensions: '4.5x3.5 inches', features: 'RFID Protection' },
    variants: [
      { id: 'var-201-1', name: 'Brown', sku: 'LG-WL-001-BR', price: 49.99, inventory: 25, attributes: { color: 'Brown' } },
      { id: 'var-201-2', name: 'Black', sku: 'LG-WL-001-BK', price: 49.99, inventory: 20, attributes: { color: 'Black' } },
    ],
    rating: 4.8,
    reviewCount: 167,
    tags: ['wallet', 'accessories', 'premium'],
    isFeatured: true,
    isNew: false,
    createdAt: '2023-06-01',
  },
  {
    id: 'prod-202',
    name: 'Elegant Leather Handbag',
    slug: 'elegant-leather-handbag',
    description: 'Sophisticated handbag crafted from premium leather with gold-tone hardware. Spacious interior with multiple compartments for organized storage. Perfect for work or evening events.',
    shortDescription: 'Sophisticated leather handbag',
    price: 149.99,
    sku: 'LG-HB-002',
    inventory: 23,
    categoryId: 'cat-6',
    category: 'Bags',
    images: ['/images/leather/leather-2.jpg'],
    attributes: { material: 'Premium Leather', dimensions: '12x9x5 inches', features: 'Gold-tone hardware' },
    rating: 4.9,
    reviewCount: 98,
    tags: ['handbag', 'fashion', 'luxury'],
    isFeatured: true,
    isNew: true,
    createdAt: '2024-02-01',
  },
  {
    id: 'prod-203',
    name: 'Classic Leather Belt',
    slug: 'classic-leather-belt',
    description: 'Timeless leather belt with classic buckle design. Made from genuine leather that develops a beautiful patina over time. Available in multiple sizes.',
    shortDescription: 'Genuine leather belt with classic buckle',
    price: 39.99,
    comparePrice: 49.99,
    sku: 'LG-BT-003',
    inventory: 78,
    categoryId: 'cat-6',
    category: 'Accessories',
    images: ['/images/leather/leather-3.jpg'],
    attributes: { material: 'Genuine Leather', width: '1.5 inches', buckle: 'Silver-tone' },
    variants: [
      { id: 'var-203-1', name: 'Size 32', sku: 'LG-BT-003-32', price: 39.99, inventory: 20, attributes: { size: '32' } },
      { id: 'var-203-2', name: 'Size 34', sku: 'LG-BT-003-34', price: 39.99, inventory: 25, attributes: { size: '34' } },
      { id: 'var-203-3', name: 'Size 36', sku: 'LG-BT-003-36', price: 39.99, inventory: 18, attributes: { size: '36' } },
      { id: 'var-203-4', name: 'Size 38', sku: 'LG-BT-003-38', price: 39.99, inventory: 15, attributes: { size: '38' } },
    ],
    rating: 4.7,
    reviewCount: 134,
    tags: ['belt', 'accessories', 'sale'],
    isFeatured: false,
    isNew: false,
    createdAt: '2023-09-15',
  },
  {
    id: 'prod-204',
    name: 'Leather Watch Strap',
    slug: 'leather-watch-strap',
    description: 'Premium leather watch strap with quick-release pins for easy changing. Compatible with most standard watches. Soft, comfortable, and durable.',
    shortDescription: 'Premium leather watch strap',
    price: 29.99,
    sku: 'LG-WS-004',
    inventory: 112,
    categoryId: 'cat-6',
    category: 'Accessories',
    images: ['/images/leather/leather-4.jpg'],
    attributes: { material: 'Genuine Leather', width: '20mm', features: 'Quick-release' },
    variants: [
      { id: 'var-204-1', name: 'Black 20mm', sku: 'LG-WS-004-BK20', price: 29.99, inventory: 45, attributes: { color: 'Black', width: '20mm' } },
      { id: 'var-204-2', name: 'Brown 20mm', sku: 'LG-WS-004-BR20', price: 29.99, inventory: 38, attributes: { color: 'Brown', width: '20mm' } },
      { id: 'var-204-3', name: 'Black 22mm', sku: 'LG-WS-004-BK22', price: 29.99, inventory: 29, attributes: { color: 'Black', width: '22mm' } },
    ],
    rating: 4.6,
    reviewCount: 87,
    tags: ['watch', 'accessories'],
    isFeatured: false,
    isNew: true,
    createdAt: '2024-01-25',
  },
];

export const reviews: Review[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    userId: 'user-1',
    userName: 'Sarah Mitchell',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    title: 'Absolutely captivating!',
    content: 'This book completely transported me to another world. The character development is exceptional and the plot twists kept me guessing until the very end. Highly recommend!',
    helpfulCount: 24,
    verified: true,
    createdAt: '2024-02-10',
  },
  {
    id: 'rev-2',
    productId: 'prod-1',
    userId: 'user-2',
    userName: 'James Wilson',
    rating: 4,
    title: 'Great read, minor pacing issues',
    content: 'Overall a fantastic book with rich world-building. The middle section dragged a bit, but the ending more than made up for it.',
    helpfulCount: 12,
    verified: true,
    createdAt: '2024-01-28',
  },
  {
    id: 'rev-3',
    productId: 'prod-101',
    userId: 'user-3',
    userName: 'Emily Parker',
    userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face',
    rating: 5,
    title: 'So soft and adorable!',
    content: 'This onesie is incredibly soft and the print is even cuter in person. My baby loves it and it washes really well. Will definitely buy more!',
    helpfulCount: 18,
    verified: true,
    createdAt: '2024-01-15',
  },
];

export const coupons: Coupon[] = [
  {
    id: 'coup-1',
    code: 'WELCOME20',
    type: 'percentage',
    value: 20,
    minOrder: 50,
    maxUses: 1000,
    usedCount: 456,
    expiresAt: '2024-12-31',
  },
  {
    id: 'coup-2',
    code: 'FLASH50',
    type: 'percentage',
    value: 50,
    minOrder: 100,
    maxUses: 100,
    usedCount: 67,
    expiresAt: '2024-03-31',
  },
  {
    id: 'coup-3',
    code: 'SAVE10',
    type: 'fixed',
    value: 10,
    maxUses: 500,
    usedCount: 234,
    expiresAt: '2024-06-30',
  },
];

// In-memory storage for dynamic data
export let cartItems: CartItem[] = [];
export let orders: Order[] = [];
export let users: User[] = [];
export let wishlistItems: { userId: string; productId: string }[] = [];

// Helper functions
export const getProductById = (id: string): Product | undefined => {
  return products.find(p => p.id === id);
};

export const getProductsByCategory = (categoryId: string): Product[] => {
  return products.filter(p => p.categoryId === categoryId);
};

export const getReviewsByProduct = (productId: string): Review[] => {
  return reviews.filter(r => r.productId === productId);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(p => p.isFeatured);
};

export const getNewProducts = (): Product[] => {
  return products.filter(p => p.isNew);
};

export const searchProducts = (query: string): Product[] => {
  const lowerQuery = query.toLowerCase();
  return products.filter(p => 
    p.name.toLowerCase().includes(lowerQuery) ||
    p.description.toLowerCase().includes(lowerQuery) ||
    p.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
  );
};

