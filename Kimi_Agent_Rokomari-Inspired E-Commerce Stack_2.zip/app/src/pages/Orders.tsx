import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Package, ChevronRight, Clock, CheckCircle, Truck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '../context/AuthContext';
import { ordersAPI } from '../api/apiService';
import type { Order } from '../data/mockDatabase';

const statusConfig = {
  pending: { color: 'bg-[#f59e0b]', icon: Clock, label: 'Pending' },
  processing: { color: 'bg-[#6366f1]', icon: Package, label: 'Processing' },
  shipped: { color: 'bg-[#3b82f6]', icon: Truck, label: 'Shipped' },
  delivered: { color: 'bg-[#10b981]', icon: CheckCircle, label: 'Delivered' },
  cancelled: { color: 'bg-[#ef4444]', icon: Clock, label: 'Cancelled' },
};

export default function Orders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOrders = async () => {
      if (!user) return;
      try {
        const data = await ordersAPI.getAll(user.id);
        setOrders(data);
      } catch (error) {
        console.error('Failed to load orders');
      } finally {
        setLoading(false);
      }
    };
    loadOrders();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-[#6366f1] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="min-h-screen py-24 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="w-32 h-32 mx-auto bg-[#1a1a2e] rounded-full flex items-center justify-center mb-6">
            <Package className="w-16 h-16 text-white/30" />
          </div>
          <h2 className="text-3xl font-bold mb-4">No Orders Yet</h2>
          <p className="text-white/50 mb-8 max-w-md mx-auto">
            You haven't placed any orders yet. Start shopping to see your orders here.
          </p>
          <Link to="/">
            <button className="px-8 py-3 bg-gradient-to-r from-[#6366f1] to-[#ec4899] rounded-full font-semibold">
              Start Shopping
            </button>
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-8"
        >
          My Orders
        </motion.h1>

        <div className="space-y-4">
          {orders.map((order, index) => {
            const status = statusConfig[order.status];
            const StatusIcon = status.icon;
            
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={`/order/${order.id}`}>
                  <div className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5 hover:border-[#6366f1]/50 transition-all">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 ${status.color} rounded-xl flex items-center justify-center`}>
                          <StatusIcon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold text-white">Order #{order.id}</p>
                          <p className="text-sm text-white/50">
                            {new Date(order.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric',
                            })}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="font-semibold text-white">${order.total.toFixed(2)}</p>
                          <p className="text-sm text-white/50">{order.items.length} items</p>
                        </div>
                        <Badge className={`${status.color} text-white`}>
                          {status.label}
                        </Badge>
                        <ChevronRight className="w-5 h-5 text-white/40" />
                      </div>
                    </div>

                    {/* Preview Items */}
                    <div className="flex gap-3 mt-4 pt-4 border-t border-white/5">
                      {order.items.slice(0, 4).map((item) => (
                        <img
                          key={item.id}
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-20 object-cover rounded-lg"
                        />
                      ))}
                      {order.items.length > 4 && (
                        <div className="w-16 h-20 bg-[#0f0f23] rounded-lg flex items-center justify-center">
                          <span className="text-sm text-white/50">+{order.items.length - 4}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
