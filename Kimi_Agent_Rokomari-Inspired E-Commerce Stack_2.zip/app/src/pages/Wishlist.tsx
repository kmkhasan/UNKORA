import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingCart, Trash2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { wishlistAPI } from '../api/apiService';
import type { Product } from '../data/mockDatabase';
import { toast } from 'sonner';

export default function Wishlist() {
  const { user } = useAuth();
  const { addItem } = useCart();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadWishlist = async () => {
      if (!user) return;
      try {
        const data = await wishlistAPI.get(user.id);
        setProducts(data);
      } catch (error) {
        console.error('Failed to load wishlist');
      } finally {
        setLoading(false);
      }
    };
    loadWishlist();
  }, [user]);

  const removeFromWishlist = async (productId: string) => {
    if (!user) return;
    try {
      await wishlistAPI.remove(user.id, productId);
      setProducts(products.filter(p => p.id !== productId));
      toast.success('Removed from wishlist');
    } catch (error) {
      toast.error('Failed to remove');
    }
  };

  const moveToCart = async (product: Product) => {
    try {
      await addItem(product.id, 1);
      if (user) {
        await wishlistAPI.remove(user.id, product.id);
      }
      setProducts(products.filter(p => p.id !== product.id));
      toast.success('Moved to cart');
    } catch (error) {
      toast.error('Failed to move to cart');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-[#6366f1] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="min-h-screen py-24 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="w-32 h-32 mx-auto bg-[#1a1a2e] rounded-full flex items-center justify-center mb-6">
            <Heart className="w-16 h-16 text-white/30" />
          </div>
          <h2 className="text-3xl font-bold mb-4">Your Wishlist is Empty</h2>
          <p className="text-white/50 mb-8 max-w-md mx-auto">
            Save items you love to your wishlist and they'll be here when you're ready.
          </p>
          <Link to="/">
            <Button className="bg-gradient-to-r from-[#6366f1] to-[#ec4899]">
              Start Shopping
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-8"
        >
          My Wishlist ({products.length})
        </motion.h1>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-[#1a1a2e] rounded-2xl overflow-hidden border border-white/5"
            >
              <div className="relative aspect-[3/4] overflow-hidden">
                <Link to={`/product/${product.slug}`}>
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                </Link>
                
                {/* Remove Button */}
                <button
                  onClick={() => removeFromWishlist(product.id)}
                  className="absolute top-4 right-4 w-10 h-10 bg-[#0f0f23]/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-[#ef4444]"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-4">
                <Link to={`/product/${product.slug}`}>
                  <h3 className="font-semibold text-white mb-2 line-clamp-2 group-hover:text-[#6366f1] transition-colors">
                    {product.name}
                  </h3>
                </Link>
                <p className="text-xl font-bold text-white mb-4">${product.price.toFixed(2)}</p>
                
                <Button
                  onClick={() => moveToCart(product)}
                  className="w-full bg-gradient-to-r from-[#6366f1] to-[#ec4899]"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Add to Cart
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
