import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Star, Heart, Share2, Truck, RotateCcw, Shield, Check,
  Minus, Plus, ShoppingCart, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { productsAPI, reviewsAPI } from '../api/apiService';
import type { Product, Review } from '../data/mockDatabase';
import { useCart } from '../context/CartContext';
import { toast } from 'sonner';

// Image Gallery Component
function ImageGallery({ images, productName }: { images: string[]; productName: string }) {
  const [selectedImage, setSelectedImage] = useState(0);

  return (
    <div className="space-y-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="aspect-square bg-[#1a1a2e] rounded-2xl overflow-hidden"
      >
        <AnimatePresence mode="wait">
          <motion.img
            key={selectedImage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            src={images[selectedImage]}
            alt={productName}
            className="w-full h-full object-cover"
          />
        </AnimatePresence>
      </motion.div>
      
      {images.length > 1 && (
        <div className="flex gap-3">
          {images.map((image, index) => (
            <motion.button
              key={index}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedImage(index)}
              className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-colors ${
                selectedImage === index 
                  ? 'border-[#6366f1]' 
                  : 'border-transparent hover:border-white/20'
              }`}
            >
              <img src={image} alt={`${productName} ${index + 1}`} className="w-full h-full object-cover" />
            </motion.button>
          ))}
        </div>
      )}
    </div>
  );
}

// Review Card Component
function ReviewCard({ review }: { review: Review }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[#1a1a2e] rounded-xl p-6 border border-white/5"
    >
      <div className="flex items-start gap-4">
        <img
          src={review.userAvatar || `https://ui-avatars.com/api/?name=${review.userName}&background=6366f1&color=fff`}
          alt={review.userName}
          className="w-12 h-12 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="font-semibold text-white">{review.userName}</p>
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${i < review.rating ? 'text-[#f59e0b] fill-current' : 'text-white/20'}`} 
                    />
                  ))}
                </div>
                {review.verified && (
                  <Badge variant="outline" className="text-xs border-[#10b981] text-[#10b981]">
                    <Check className="w-3 h-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
            </div>
            <span className="text-sm text-white/40">
              {new Date(review.createdAt).toLocaleDateString()}
            </span>
          </div>
          <h4 className="font-medium text-white mb-2">{review.title}</h4>
          <p className="text-white/60 text-sm">{review.content}</p>
        </div>
      </div>
    </motion.div>
  );
}

// Main Product Detail Component
export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState<string | undefined>();
  const [isWishlisted, setIsWishlisted] = useState(false);
  
  const { addItem } = useCart();

  useEffect(() => {
    const loadProduct = async () => {
      if (!slug) return;
      try {
        const prod = await productsAPI.getBySlug(slug);
        setProduct(prod);
        const revs = await reviewsAPI.getByProduct(prod.id);
        setReviews(revs);
      } catch (error) {
        toast.error('Product not found');
      } finally {
        setLoading(false);
      }
    };
    loadProduct();
  }, [slug]);

  const handleAddToCart = async () => {
    if (!product) return;
    try {
      await addItem(product.id, quantity, selectedVariant);
    } catch (error) {
      toast.error('Failed to add to cart');
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Link copied to clipboard!');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-[#6366f1] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentPrice = selectedVariant 
    ? product.variants?.find(v => v.id === selectedVariant)?.price || product.price
    : product.price;

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumbs */}
        <motion.nav
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 text-sm text-white/50 mb-8"
        >
          <Link to="/" className="hover:text-white transition-colors">Home</Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/category/${product.categoryId}`} className="hover:text-white transition-colors">
            {product.category}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-white">{product.name}</span>
        </motion.nav>

        {/* Product Grid */}
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Images */}
          <ImageGallery images={product.images} productName={product.name} />

          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            {/* Badges */}
            <div className="flex gap-2 mb-4">
              {product.isNew && (
                <Badge className="bg-[#10b981] text-white">New Arrival</Badge>
              )}
              {product.discount && (
                <Badge className="bg-[#ef4444] text-white">-{product.discount}% Off</Badge>
              )}
              {product.inventory < 10 && (
                <Badge variant="outline" className="border-[#f59e0b] text-[#f59e0b]">
                  Low Stock
                </Badge>
              )}
            </div>

            {/* Title & Rating */}
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">{product.name}</h1>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'text-[#f59e0b] fill-current' : 'text-white/20'}`} 
                  />
                ))}
                <span className="text-white ml-2">{product.rating}</span>
              </div>
              <span className="text-white/40">|</span>
              <span className="text-white/60">{product.reviewCount} reviews</span>
            </div>

            {/* Price */}
            <div className="flex items-center gap-4 mb-6">
              <span className="text-4xl font-bold text-white">${currentPrice.toFixed(2)}</span>
              {product.comparePrice && (
                <span className="text-xl text-white/40 line-through">
                  ${product.comparePrice.toFixed(2)}
                </span>
              )}
            </div>

            {/* Short Description */}
            <p className="text-white/60 mb-8">{product.shortDescription}</p>

            {/* Variants */}
            {product.variants && product.variants.length > 0 && (
              <div className="mb-6">
                <p className="text-sm text-white/50 mb-3">Select Option</p>
                <div className="flex gap-3">
                  {product.variants.map((variant) => (
                    <motion.button
                      key={variant.id}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setSelectedVariant(variant.id)}
                      className={`px-4 py-2 rounded-lg border transition-all ${
                        selectedVariant === variant.id
                          ? 'border-[#6366f1] bg-[#6366f1]/20 text-white'
                          : 'border-white/10 text-white/60 hover:border-white/30'
                      }`}
                    >
                      {variant.name}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="mb-8">
              <p className="text-sm text-white/50 mb-3">Quantity</p>
              <div className="flex items-center gap-4">
                <div className="flex items-center bg-[#1a1a2e] rounded-lg border border-white/10">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-3 hover:bg-white/5 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-semibold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-3 hover:bg-white/5 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <span className="text-sm text-white/50">
                  {product.inventory} items available
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-4 mb-8">
              <Button
                onClick={handleAddToCart}
                size="lg"
                className="flex-1 bg-gradient-to-r from-[#6366f1] to-[#ec4899] hover:opacity-90 text-white py-6 rounded-xl"
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Add to Cart
              </Button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsWishlisted(!isWishlisted)}
                className={`p-4 rounded-xl border transition-colors ${
                  isWishlisted 
                    ? 'bg-[#ec4899]/20 border-[#ec4899] text-[#ec4899]' 
                    : 'border-white/10 text-white/60 hover:border-white/30'
                }`}
              >
                <Heart className={`w-6 h-6 ${isWishlisted ? 'fill-current' : ''}`} />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleShare}
                className="p-4 rounded-xl border border-white/10 text-white/60 hover:border-white/30 transition-colors"
              >
                <Share2 className="w-6 h-6" />
              </motion.button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2 text-sm text-white/60">
                <Truck className="w-5 h-5 text-[#6366f1]" />
                Free Shipping
              </div>
              <div className="flex items-center gap-2 text-sm text-white/60">
                <RotateCcw className="w-5 h-5 text-[#ec4899]" />
                Easy Returns
              </div>
              <div className="flex items-center gap-2 text-sm text-white/60">
                <Shield className="w-5 h-5 text-[#10b981]" />
                Secure Payment
              </div>
            </div>
          </motion.div>
        </div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-16"
        >
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="bg-[#1a1a2e] border border-white/10 p-1 rounded-xl">
              <TabsTrigger value="description" className="data-[state=active]:bg-[#6366f1] rounded-lg">
                Description
              </TabsTrigger>
              <TabsTrigger value="details" className="data-[state=active]:bg-[#6366f1] rounded-lg">
                Details
              </TabsTrigger>
              <TabsTrigger value="reviews" className="data-[state=active]:bg-[#6366f1] rounded-lg">
                Reviews ({reviews.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <div className="bg-[#1a1a2e] rounded-2xl p-8 border border-white/5">
                <p className="text-white/70 leading-relaxed">{product.description}</p>
              </div>
            </TabsContent>
            
            <TabsContent value="details" className="mt-6">
              <div className="bg-[#1a1a2e] rounded-2xl p-8 border border-white/5">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {Object.entries(product.attributes).map(([key, value]) => (
                    <div key={key}>
                      <p className="text-sm text-white/50 mb-1 capitalize">{key}</p>
                      <p className="text-white font-medium">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-4">
                {reviews.length > 0 ? (
                  reviews.map((review) => <ReviewCard key={review.id} review={review} />)
                ) : (
                  <div className="text-center py-12 bg-[#1a1a2e] rounded-2xl border border-white/5">
                    <p className="text-white/50">No reviews yet</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
