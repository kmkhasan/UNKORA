import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, Package, ShoppingCart, Plus, Search, 
  Edit2, Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { adminAPI } from '../../api/apiService';
import type { Product } from '../../data/mockDatabase';
import { toast } from 'sonner';

const sidebarLinks = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
];

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const loadProducts = async () => {
      try {
        // Get all products from mock database
        const { products: allProducts } = await import('../../data/mockDatabase');
        setProducts(allProducts);
      } catch (error) {
        console.error('Failed to load products');
      }
    };
    loadProducts();
  }, []);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
      await adminAPI.deleteProduct(id);
      setProducts(products.filter(p => p.id !== id));
      toast.success('Product deleted');
    } catch (error) {
      toast.error('Failed to delete product');
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.sku.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex bg-[#0f0f23]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1a1a2e] border-r border-white/5 fixed h-full">
        <div className="p-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#6366f1] to-[#ec4899] rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">B</span>
            </div>
            <span className="text-xl font-bold">Admin</span>
          </Link>
        </div>
        
        <nav className="px-4 py-4">
          {sidebarLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.href;
            return (
              <Link
                key={link.name}
                to={link.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors mb-1 ${
                  isActive 
                    ? 'bg-[#6366f1] text-white' 
                    : 'text-white/60 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {link.name}
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <h1 className="text-3xl font-bold">Products</h1>
            <Button className="bg-gradient-to-r from-[#6366f1] to-[#ec4899]">
              <Plus className="w-5 h-5 mr-2" />
              Add Product
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-[#1a1a2e] border-white/10"
            />
          </div>

          {/* Products Table */}
          <div className="bg-[#1a1a2e] rounded-2xl border border-white/5 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#0f0f23]">
                  <tr>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Product</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">SKU</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Price</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Stock</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Status</th>
                    <th className="text-right px-6 py-4 text-sm font-medium text-white/50">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product) => (
                    <tr key={product.id} className="border-t border-white/5 hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            className="w-12 h-16 object-cover rounded-lg"
                          />
                          <div>
                            <p className="font-medium">{product.name}</p>
                            <p className="text-sm text-white/50">{product.category}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-white/70">{product.sku}</td>
                      <td className="px-6 py-4">
                        <span className="font-medium">${product.price.toFixed(2)}</span>
                        {product.comparePrice && (
                          <span className="text-sm text-white/40 line-through ml-2">
                            ${product.comparePrice.toFixed(2)}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={product.inventory < 10 ? 'text-[#ef4444]' : 'text-white/70'}>
                          {product.inventory} units
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          {product.isFeatured && (
                            <Badge className="bg-[#6366f1]">Featured</Badge>
                          )}
                          {product.isNew && (
                            <Badge className="bg-[#10b981]">New</Badge>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(product.id)}
                            className="p-2 hover:bg-[#ef4444]/20 text-[#ef4444] rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
