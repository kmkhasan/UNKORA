import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, Package, ShoppingCart, Users, 
  DollarSign, ArrowUpRight, ArrowDownRight 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { adminAPI } from '../../api/apiService';
import type { Order } from '../../data/mockDatabase';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';

const sidebarLinks = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
];

interface DashboardStats {
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  totalProducts: number;
  recentOrders: Order[];
  salesByMonth: { month: string; sales: number }[];
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const data = await adminAPI.getDashboardStats();
        setStats(data);
      } catch (error) {
        console.error('Failed to load stats');
      } finally {
        setLoading(false);
      }
    };
    loadStats();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0f0f23]">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-[#6366f1] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  const statCards = [
    { 
      name: 'Total Revenue', 
      value: `$${(stats?.totalRevenue || 0).toLocaleString()}`, 
      icon: DollarSign, 
      change: '+12.5%',
      changeType: 'positive' as const,
      color: '#6366f1'
    },
    { 
      name: 'Total Orders', 
      value: (stats?.totalOrders || 0).toLocaleString(), 
      icon: ShoppingCart, 
      change: '+8.2%',
      changeType: 'positive' as const,
      color: '#ec4899'
    },
    { 
      name: 'Total Customers', 
      value: (stats?.totalCustomers || 0).toLocaleString(), 
      icon: Users, 
      change: '+15.3%',
      changeType: 'positive' as const,
      color: '#10b981'
    },
    { 
      name: 'Total Products', 
      value: (stats?.totalProducts || 0).toLocaleString(), 
      icon: Package, 
      change: '+5.1%',
      changeType: 'positive' as const,
      color: '#f59e0b'
    },
  ];

  return (
    <div className="min-h-screen flex bg-[#0f0f23]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1a1a2e] border-r border-white/5 fixed h-full">
        <div className="p-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#6366f1] to-[#ec4899] rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">B</span>
            </div>
            <span className="text-xl font-bold">Admin</span>
          </Link>
        </div>
        
        <nav className="px-4 py-4">
          {sidebarLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.href;
            return (
              <Link
                key={link.name}
                to={link.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors mb-1 ${
                  isActive 
                    ? 'bg-[#6366f1] text-white' 
                    : 'text-white/60 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {link.name}
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-8">Dashboard</h1>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statCards.map((stat, index) => {
              const Icon = stat.icon;
              const ChangeIcon = stat.changeType === 'positive' ? ArrowUpRight : ArrowDownRight;
              
              return (
                <motion.div
                  key={stat.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${stat.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: stat.color }} />
                    </div>
                    <div className={`flex items-center gap-1 text-sm ${
                      stat.changeType === 'positive' ? 'text-[#10b981]' : 'text-[#ef4444]'
                    }`}>
                      <ChangeIcon className="w-4 h-4" />
                      {stat.change}
                    </div>
                  </div>
                  <p className="text-white/50 text-sm">{stat.name}</p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                </motion.div>
              );
            })}
          </div>

          {/* Charts & Recent Orders */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Sales Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="lg:col-span-2 bg-[#1a1a2e] rounded-2xl p-6 border border-white/5"
            >
              <h2 className="text-xl font-bold mb-6">Sales Overview</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats?.salesByMonth || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27273a" />
                    <XAxis dataKey="month" stroke="#71717a" />
                    <YAxis stroke="#71717a" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1a1a2e', 
                        border: '1px solid #27273a',
                        borderRadius: '8px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="sales" 
                      stroke="#6366f1" 
                      strokeWidth={3}
                      dot={{ fill: '#6366f1', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Recent Orders */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Recent Orders</h2>
                <Link to="/admin/orders" className="text-[#6366f1] text-sm hover:underline">
                  View All
                </Link>
              </div>
              
              <div className="space-y-4">
                {stats?.recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center gap-4 p-4 bg-[#0f0f23] rounded-xl">
                    <div className="w-10 h-10 bg-[#6366f1]/20 rounded-lg flex items-center justify-center">
                      <ShoppingCart className="w-5 h-5 text-[#6366f1]" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">#{order.id}</p>
                      <p className="text-xs text-white/50">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <p className="font-semibold">${order.total.toFixed(2)}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
