import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, Package, ShoppingCart, Search, Eye
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { adminAPI } from '../../api/apiService';
import type { Order } from '../../data/mockDatabase';
import { toast } from 'sonner';

const sidebarLinks = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Products', href: '/admin/products', icon: Package },
  { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
];

const statusOptions = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];

const statusConfig = {
  pending: { color: 'bg-[#f59e0b]', label: 'Pending' },
  processing: { color: 'bg-[#6366f1]', label: 'Processing' },
  shipped: { color: 'bg-[#3b82f6]', label: 'Shipped' },
  delivered: { color: 'bg-[#10b981]', label: 'Delivered' },
  cancelled: { color: 'bg-[#ef4444]', label: 'Cancelled' },
};

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const loadOrders = async () => {
      try {
        const data = await adminAPI.getAllOrders();
        setOrders(data);
      } catch (error) {
        console.error('Failed to load orders');
      }
    };
    loadOrders();
  }, []);

  const handleStatusChange = async (orderId: string, newStatus: Order['status']) => {
    try {
      await adminAPI.updateOrderStatus(orderId, newStatus);
      setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
      toast.success('Order status updated');
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const filteredOrders = orders.filter(o => 
    o.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex bg-[#0f0f23]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1a1a2e] border-r border-white/5 fixed h-full">
        <div className="p-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#6366f1] to-[#ec4899] rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">B</span>
            </div>
            <span className="text-xl font-bold">Admin</span>
          </Link>
        </div>
        
        <nav className="px-4 py-4">
          {sidebarLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.href;
            return (
              <Link
                key={link.name}
                to={link.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors mb-1 ${
                  isActive 
                    ? 'bg-[#6366f1] text-white' 
                    : 'text-white/60 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {link.name}
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-8">Orders</h1>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <Input
              placeholder="Search orders..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-[#1a1a2e] border-white/10"
            />
          </div>

          {/* Orders Table */}
          <div className="bg-[#1a1a2e] rounded-2xl border border-white/5 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#0f0f23]">
                  <tr>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Order ID</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Date</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Items</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Total</th>
                    <th className="text-left px-6 py-4 text-sm font-medium text-white/50">Status</th>
                    <th className="text-right px-6 py-4 text-sm font-medium text-white/50">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map((order) => {
                    const status = statusConfig[order.status];
                    return (
                      <tr key={order.id} className="border-t border-white/5 hover:bg-white/5 transition-colors">
                        <td className="px-6 py-4 font-medium">#{order.id}</td>
                        <td className="px-6 py-4 text-white/70">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-white/70">{order.items.length} items</td>
                        <td className="px-6 py-4 font-medium">${order.total.toFixed(2)}</td>
                        <td className="px-6 py-4">
                          <select
                            value={order.status}
                            onChange={(e) => handleStatusChange(order.id, e.target.value as Order['status'])}
                            className={`px-3 py-1 rounded-full text-sm text-white border-0 cursor-pointer ${status.color}`}
                          >
                            {statusOptions.map(s => (
                              <option key={s} value={s} className="bg-[#1a1a2e] text-white">
                                {s.charAt(0).toUpperCase() + s.slice(1)}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Link to={`/order/${order.id}`}>
                            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                              <Eye className="w-4 h-4" />
                            </button>
                          </Link>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
