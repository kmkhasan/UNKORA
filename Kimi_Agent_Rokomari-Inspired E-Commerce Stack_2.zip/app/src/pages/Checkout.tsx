import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, Truck, Check, ChevronRight, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { ordersAPI } from '../api/apiService';
import { toast } from 'sonner';

const steps = [
  { id: 'shipping', label: 'Shipping', icon: Truck },
  { id: 'payment', label: 'Payment', icon: CreditCard },
  { id: 'review', label: 'Review', icon: Check },
];

export default function Checkout() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { items, subtotal, tax, shipping, total, clearCart } = useCart();
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  
  const [shippingData, setShippingData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    street: '',
    city: '',
    state: '',
    zip: '',
    country: 'US',
  });
  
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiry: '',
    cvv: '',
    name: '',
  });

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep(1);
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep(2);
  };

  const handlePlaceOrder = async () => {
    setLoading(true);
    try {
      const order = await ordersAPI.create({
        userId: user?.id || 'guest',
        items: items.map(item => ({
          productId: item.productId,
          variantId: item.variantId,
          quantity: item.quantity,
        })),
        shippingAddress: {
          id: 'addr-1',
          type: 'shipping',
          street: shippingData.street,
          city: shippingData.city,
          state: shippingData.state,
          zip: shippingData.zip,
          country: shippingData.country,
          isDefault: false,
        },
        billingAddress: {
          id: 'addr-2',
          type: 'billing',
          street: shippingData.street,
          city: shippingData.city,
          state: shippingData.state,
          zip: shippingData.zip,
          country: shippingData.country,
          isDefault: false,
        },
        paymentMethod: 'card',
      });
      
      await clearCart();
      toast.success('Order placed successfully!');
      navigate(`/order/${order.id}`);
    } catch (error) {
      toast.error('Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Progress */}
        <div className="mb-12">
          <div className="flex items-center justify-center">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;
              
              return (
                <div key={step.id} className="flex items-center">
                  <motion.div
                    initial={false}
                    animate={{
                      backgroundColor: isActive || isCompleted ? '#6366f1' : '#1a1a2e',
                      borderColor: isActive || isCompleted ? '#6366f1' : '#27273a',
                    }}
                    className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${
                      isActive ? 'ring-4 ring-[#6366f1]/20' : ''
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive || isCompleted ? 'text-white' : 'text-white/40'}`} />
                  </motion.div>
                  <span className={`ml-3 ${isActive ? 'text-white' : 'text-white/40'}`}>
                    {step.label}
                  </span>
                  {index < steps.length - 1 && (
                    <ChevronRight className="w-5 h-5 mx-4 text-white/20" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-[#1a1a2e] rounded-2xl p-8 border border-white/5"
        >
          {currentStep === 0 && (
            <form onSubmit={handleShippingSubmit}>
              <h2 className="text-2xl font-bold mb-6">Shipping Information</h2>
              
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <Label>First Name</Label>
                  <Input
                    required
                    value={shippingData.firstName}
                    onChange={(e) => setShippingData({ ...shippingData, firstName: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
                <div>
                  <Label>Last Name</Label>
                  <Input
                    required
                    value={shippingData.lastName}
                    onChange={(e) => setShippingData({ ...shippingData, lastName: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
              </div>

              <div className="mb-6">
                <Label>Email</Label>
                <Input
                  type="email"
                  required
                  value={shippingData.email}
                  onChange={(e) => setShippingData({ ...shippingData, email: e.target.value })}
                  className="bg-[#0f0f23] border-white/10 mt-2"
                />
              </div>

              <div className="mb-6">
                <Label>Street Address</Label>
                <Input
                  required
                  value={shippingData.street}
                  onChange={(e) => setShippingData({ ...shippingData, street: e.target.value })}
                  className="bg-[#0f0f23] border-white/10 mt-2"
                />
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div>
                  <Label>City</Label>
                  <Input
                    required
                    value={shippingData.city}
                    onChange={(e) => setShippingData({ ...shippingData, city: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
                <div>
                  <Label>State</Label>
                  <Input
                    required
                    value={shippingData.state}
                    onChange={(e) => setShippingData({ ...shippingData, state: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
                <div>
                  <Label>ZIP Code</Label>
                  <Input
                    required
                    value={shippingData.zip}
                    onChange={(e) => setShippingData({ ...shippingData, zip: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
              </div>

              <Button 
                type="submit" 
                size="lg" 
                className="w-full bg-gradient-to-r from-[#6366f1] to-[#ec4899]"
              >
                Continue to Payment
              </Button>
            </form>
          )}

          {currentStep === 1 && (
            <form onSubmit={handlePaymentSubmit}>
              <h2 className="text-2xl font-bold mb-6">Payment Information</h2>
              
              <div className="flex items-center gap-2 mb-6 p-4 bg-[#10b981]/10 rounded-lg border border-[#10b981]/20">
                <Lock className="w-5 h-5 text-[#10b981]" />
                <span className="text-sm text-[#10b981]">Your payment information is secure and encrypted</span>
              </div>

              <div className="mb-6">
                <Label>Card Number</Label>
                <Input
                  required
                  placeholder="1234 5678 9012 3456"
                  value={paymentData.cardNumber}
                  onChange={(e) => setPaymentData({ ...paymentData, cardNumber: e.target.value })}
                  className="bg-[#0f0f23] border-white/10 mt-2"
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <Label>Expiry Date</Label>
                  <Input
                    required
                    placeholder="MM/YY"
                    value={paymentData.expiry}
                    onChange={(e) => setPaymentData({ ...paymentData, expiry: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
                <div>
                  <Label>CVV</Label>
                  <Input
                    required
                    type="password"
                    maxLength={4}
                    placeholder="123"
                    value={paymentData.cvv}
                    onChange={(e) => setPaymentData({ ...paymentData, cvv: e.target.value })}
                    className="bg-[#0f0f23] border-white/10 mt-2"
                  />
                </div>
              </div>

              <div className="mb-6">
                <Label>Cardholder Name</Label>
                <Input
                  required
                  value={paymentData.name}
                  onChange={(e) => setPaymentData({ ...paymentData, name: e.target.value })}
                  className="bg-[#0f0f23] border-white/10 mt-2"
                />
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setCurrentStep(0)}
                  className="flex-1 border-white/20"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  size="lg" 
                  className="flex-1 bg-gradient-to-r from-[#6366f1] to-[#ec4899]"
                >
                  Review Order
                </Button>
              </div>
            </form>
          )}

          {currentStep === 2 && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Review Your Order</h2>
              
              {/* Items */}
              <div className="space-y-4 mb-6">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4 p-4 bg-[#0f0f23] rounded-xl">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-16 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <p className="font-medium">{item.product.name}</p>
                      <p className="text-sm text-white/50">Qty: {item.quantity}</p>
                    </div>
                    <p className="font-semibold">
                      ${((item.variant?.price || item.product.price) * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="border-t border-white/10 pt-4 mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-white/60">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/60">Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/60">Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-xl font-bold pt-2 border-t border-white/10">
                  <span>Total</span>
                  <span className="bg-gradient-to-r from-[#6366f1] to-[#ec4899] bg-clip-text text-transparent">
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setCurrentStep(1)}
                  className="flex-1 border-white/20"
                >
                  Back
                </Button>
                <Button 
                  onClick={handlePlaceOrder}
                  disabled={loading}
                  size="lg" 
                  className="flex-1 bg-gradient-to-r from-[#6366f1] to-[#ec4899]"
                >
                  {loading ? 'Processing...' : 'Place Order'}
                </Button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
