import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, MapPin, Phone, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateUser({
        firstName: formData.firstName,
        lastName: formData.lastName,
      });
      toast.success('Profile updated successfully!');
    } catch (error) {
      toast.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-8"
        >
          My Profile
        </motion.h1>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="bg-[#1a1a2e] border border-white/10 p-1 rounded-xl mb-8">
            <TabsTrigger value="profile" className="data-[state=active]:bg-[#6366f1] rounded-lg">
              Profile
            </TabsTrigger>
            <TabsTrigger value="addresses" className="data-[state=active]:bg-[#6366f1] rounded-lg">
              Addresses
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-[#6366f1] rounded-lg">
              Security
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#1a1a2e] rounded-2xl p-8 border border-white/5"
            >
              {/* Avatar */}
              <div className="flex justify-center mb-8">
                <div className="relative">
                  <img
                    src={user?.avatar}
                    alt={user?.firstName}
                    className="w-24 h-24 rounded-full object-cover border-4 border-[#6366f1]/30"
                  />
                  <button className="absolute bottom-0 right-0 w-8 h-8 bg-[#6366f1] rounded-full flex items-center justify-center hover:bg-[#6366f1]/80 transition-colors">
                    <Camera className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label>First Name</Label>
                    <div className="relative mt-2">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                      <Input
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        className="pl-10 bg-[#0f0f23] border-white/10"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Last Name</Label>
                    <div className="relative mt-2">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                      <Input
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        className="pl-10 bg-[#0f0f23] border-white/10"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Email</Label>
                  <div className="relative mt-2">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                    <Input
                      type="email"
                      value={formData.email}
                      disabled
                      className="pl-10 bg-[#0f0f23] border-white/10 opacity-50"
                    />
                  </div>
                </div>

                <div>
                  <Label>Phone</Label>
                  <div className="relative mt-2">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                    <Input
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 (555) 000-0000"
                      className="pl-10 bg-[#0f0f23] border-white/10"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="bg-gradient-to-r from-[#6366f1] to-[#ec4899]"
                >
                  {loading ? 'Saving...' : 'Save Changes'}
                </Button>
              </form>
            </motion.div>
          </TabsContent>

          <TabsContent value="addresses">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#1a1a2e] rounded-2xl p-8 border border-white/5"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">Saved Addresses</h2>
                <Button variant="outline" className="border-white/20">
                  Add New Address
                </Button>
              </div>

              <div className="text-center py-12">
                <MapPin className="w-16 h-16 mx-auto text-white/20 mb-4" />
                <p className="text-white/50">No addresses saved yet</p>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="security">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#1a1a2e] rounded-2xl p-8 border border-white/5"
            >
              <h2 className="text-xl font-bold mb-6">Change Password</h2>
              
              <form className="space-y-6">
                <div>
                  <Label>Current Password</Label>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    className="mt-2 bg-[#0f0f23] border-white/10"
                  />
                </div>
                <div>
                  <Label>New Password</Label>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    className="mt-2 bg-[#0f0f23] border-white/10"
                  />
                </div>
                <div>
                  <Label>Confirm New Password</Label>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    className="mt-2 bg-[#0f0f23] border-white/10"
                  />
                </div>
                <Button className="bg-gradient-to-r from-[#6366f1] to-[#ec4899]">
                  Update Password
                </Button>
              </form>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
