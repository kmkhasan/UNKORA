import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Package, Clock, CheckCircle, Truck, MapPin, CreditCard } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ordersAPI } from '../api/apiService';
import type { Order } from '../data/mockDatabase';
import { toast } from 'sonner';

const statusConfig = {
  pending: { color: 'bg-[#f59e0b]', icon: Clock, label: 'Pending' },
  processing: { color: 'bg-[#6366f1]', icon: Package, label: 'Processing' },
  shipped: { color: 'bg-[#3b82f6]', icon: Truck, label: 'Shipped' },
  delivered: { color: 'bg-[#10b981]', icon: CheckCircle, label: 'Delivered' },
  cancelled: { color: 'bg-[#ef4444]', icon: Clock, label: 'Cancelled' },
};

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOrder = async () => {
      if (!id) return;
      try {
        const data = await ordersAPI.getById(id);
        setOrder(data);
      } catch (error) {
        toast.error('Order not found');
      } finally {
        setLoading(false);
      }
    };
    loadOrder();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-[#6366f1] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Order Not Found</h2>
          <Link to="/orders">
            <Button>Back to Orders</Button>
          </Link>
        </div>
      </div>
    );
  }

  const status = statusConfig[order.status];
  const StatusIcon = status.icon;

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Link to="/orders" className="flex items-center gap-2 text-white/60 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Back to Orders
          </Link>
        </motion.div>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8"
        >
          <div>
            <h1 className="text-3xl font-bold mb-2">Order #{order.id}</h1>
            <p className="text-white/50">
              Placed on {new Date(order.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </p>
          </div>
          <Badge className={`${status.color} text-white px-4 py-2 text-sm`}>
            <StatusIcon className="w-4 h-4 mr-2" />
            {status.label}
          </Badge>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Order Items */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2"
          >
            <div className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5">
              <h2 className="text-xl font-bold mb-6">Order Items</h2>
              
              <div className="space-y-4">
                {order.items.map((item) => (
                  <div key={item.id} className="flex gap-4 p-4 bg-[#0f0f23] rounded-xl">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-20 h-24 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <p className="font-semibold text-white">{item.name}</p>
                      <p className="text-sm text-white/50">Qty: {item.quantity}</p>
                      <p className="text-[#6366f1] font-semibold mt-2">
                        ${item.price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tracking */}
            {order.tracking && (
              <div className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5 mt-6">
                <h2 className="text-xl font-bold mb-6">Tracking Information</h2>
                <div className="flex items-center gap-4 mb-4">
                  <Truck className="w-6 h-6 text-[#6366f1]" />
                  <div>
                    <p className="font-semibold">{order.tracking.carrier}</p>
                    <p className="text-sm text-white/50">{order.tracking.trackingNumber}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {order.tracking.events.map((event, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="w-3 h-3 mt-1.5 rounded-full bg-[#6366f1]" />
                      <div>
                        <p className="font-medium">{event.status}</p>
                        <p className="text-sm text-white/50">{event.location}</p>
                        <p className="text-xs text-white/30">
                          {new Date(event.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            {/* Totals */}
            <div className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5">
              <h2 className="text-xl font-bold mb-6">Order Summary</h2>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-white/60">
                  <span>Subtotal</span>
                  <span>${order.subtotal.toFixed(2)}</span>
                </div>
                {order.discount > 0 && (
                  <div className="flex justify-between text-[#10b981]">
                    <span>Discount</span>
                    <span>-${order.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-white/60">
                  <span>Tax</span>
                  <span>${order.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-white/60">
                  <span>Shipping</span>
                  <span>{order.shipping === 0 ? 'Free' : `$${order.shipping.toFixed(2)}`}</span>
                </div>
                <div className="border-t border-white/10 pt-3">
                  <div className="flex justify-between text-xl font-bold">
                    <span>Total</span>
                    <span className="bg-gradient-to-r from-[#6366f1] to-[#ec4899] bg-clip-text text-transparent">
                      ${order.total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Shipping Address */}
            <div className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5">
              <div className="flex items-center gap-3 mb-4">
                <MapPin className="w-5 h-5 text-[#6366f1]" />
                <h2 className="text-lg font-bold">Shipping Address</h2>
              </div>
              <p className="text-white/70">
                {order.shippingAddress.street}<br />
                {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}<br />
                {order.shippingAddress.country}
              </p>
            </div>

            {/* Payment Method */}
            <div className="bg-[#1a1a2e] rounded-2xl p-6 border border-white/5">
              <div className="flex items-center gap-3 mb-4">
                <CreditCard className="w-5 h-5 text-[#6366f1]" />
                <h2 className="text-lg font-bold">Payment Method</h2>
              </div>
              <p className="text-white/70 capitalize">{order.paymentMethod}</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
