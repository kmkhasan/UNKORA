import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronRight, Star, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { productsAPI, categoriesAPI } from '../api/apiService';
import type { Product, Category } from '../data/mockDatabase';

const sortOptions = [
  { value: 'featured', label: 'Featured' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'rating', label: 'Highest Rated' },
  { value: 'newest', label: 'Newest' },
];

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<Category | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('featured');

  useEffect(() => {
    const loadData = async () => {
      if (!slug) return;
      try {
        const cat = await categoriesAPI.getBySlug(slug);
        setCategory(cat);
        const result = await productsAPI.getAll({ 
          category: cat.id,
          sort: sortBy !== 'featured' ? sortBy : undefined,
        });
        setProducts(result.products);
      } catch (error) {
        console.error('Failed to load category');
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [slug, sortBy]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-[#6366f1] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Category Not Found</h2>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumbs */}
        <motion.nav
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 text-sm text-white/50 mb-6"
        >
          <Link to="/" className="hover:text-white transition-colors">Home</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-white">{category.name}</span>
        </motion.nav>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative rounded-3xl overflow-hidden mb-12"
        >
          <div className="aspect-[21/9] md:aspect-[3/1]">
            <img
              src={category.image}
              alt={category.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0f0f23]/90 via-[#0f0f23]/50 to-transparent" />
          </div>
          
          <div className="absolute inset-0 flex items-center p-8 md:p-12">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2">{category.name}</h1>
              <p className="text-white/60 max-w-lg">{category.description}</p>
              <p className="text-white/40 mt-2">{category.productCount} products</p>
            </div>
          </div>
        </motion.div>

        {/* Filters & Sort */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8"
        >
          <p className="text-white/50">
            Showing {products.length} products
          </p>

          <div className="flex items-center gap-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="appearance-none bg-[#1a1a2e] border border-white/10 rounded-lg px-4 py-2 pr-10 text-sm focus:outline-none focus:border-[#6366f1]"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>

            <Button variant="outline" className="border-white/20">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </motion.div>

        {/* Products Grid */}
        {products.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Link to={`/product/${product.slug}`}>
                  <div className="group bg-[#1a1a2e] rounded-2xl overflow-hidden border border-white/5 hover:border-[#6366f1]/50 transition-all duration-500">
                    <div className="relative aspect-[3/4] overflow-hidden">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                      {product.discount && (
                        <Badge className="absolute top-4 left-4 bg-[#ef4444] text-white">
                          -{product.discount}%
                        </Badge>
                      )}
                      {product.isNew && (
                        <Badge className="absolute top-4 right-4 bg-[#10b981] text-white">
                          New
                        </Badge>
                      )}
                    </div>
                    
                    <div className="p-4">
                      <h3 className="font-semibold text-white mb-2 line-clamp-2 group-hover:text-[#6366f1] transition-colors">
                        {product.name}
                      </h3>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`w-3 h-3 ${i < Math.floor(product.rating) ? 'text-[#f59e0b] fill-current' : 'text-white/20'}`} 
                            />
                          ))}
                        </div>
                        <span className="text-xs text-white/50">({product.reviewCount})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-white">${product.price.toFixed(2)}</span>
                        {product.comparePrice && (
                          <span className="text-sm text-white/40 line-through">
                            ${product.comparePrice.toFixed(2)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <p className="text-white/50">No products found in this category</p>
          </div>
        )}
      </div>
    </div>
  );
}
