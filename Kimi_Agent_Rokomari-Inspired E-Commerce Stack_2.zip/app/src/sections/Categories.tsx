import { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';

const categories = [
  {
    id: 1,
    name: 'Fiction Books',
    count: '1200+',
    image: '/images/categories/fiction.jpg',
    color: '#f06c4e',
  },
  {
    id: 2,
    name: 'Non-Fiction',
    count: '800+',
    image: '/images/categories/non-fiction.jpg',
    color: '#283b59',
  },
  {
    id: 3,
    name: 'Children\'s Books',
    count: '500+',
    image: '/images/categories/children.jpg',
    color: '#4caf50',
  },
  {
    id: 4,
    name: 'Academic',
    count: '2000+',
    image: '/images/categories/academic.jpg',
    color: '#ff9800',
  },
];

export default function Categories() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section ref={sectionRef} className="py-16 lg:py-24 bg-white">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-12 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="section-title text-3xl lg:text-4xl font-bold text-[#283b59] mb-4">
            Shop by Category
          </h2>
          <p className="text-[#4f4f4f] max-w-2xl mx-auto">
            Explore our wide range of books across different categories. Find your perfect read today.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <div
              key={category.id}
              onClick={() => scrollToSection('#books')}
              className={`category-card group relative overflow-hidden rounded-2xl cursor-pointer bg-gray-50 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{
                transitionDelay: `${index * 150 + 200}ms`,
              }}
            >
              {/* Image */}
              <div className="aspect-square overflow-hidden">
                <img
                  src={category.image}
                  alt={category.name}
                  className="category-image w-full h-full object-cover"
                />
              </div>

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <span
                  className="inline-block text-xs font-semibold px-3 py-1 rounded-full mb-2"
                  style={{ backgroundColor: category.color }}
                >
                  {category.count} Titles
                </span>
                <h3 className="text-xl font-bold mb-2 group-hover:translate-y-[-4px] transition-transform">
                  {category.name}
                </h3>
                <div className="flex items-center gap-2 text-sm opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0">
                  <span>Explore Now</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>

              {/* Hover Border Effect */}
              <div
                className="absolute inset-0 border-4 border-transparent group-hover:border-opacity-30 rounded-2xl transition-all duration-300"
                style={{ borderColor: category.color }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
