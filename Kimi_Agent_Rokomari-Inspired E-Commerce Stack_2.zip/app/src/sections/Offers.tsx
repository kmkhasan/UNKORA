import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export default function Offers() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [timeLeft, setTimeLeft] = useState({
    days: 3,
    hours: 12,
    minutes: 45,
    seconds: 30,
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { days, hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) {
          seconds = 59;
          minutes--;
        }
        if (minutes < 0) {
          minutes = 59;
          hours--;
        }
        if (hours < 0) {
          hours = 23;
          days--;
        }
        if (days < 0) {
          days = 0;
          hours = 0;
          minutes = 0;
          seconds = 0;
        }
        return { days, hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const TimeUnit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="w-16 h-16 md:w-20 md:h-20 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mb-2">
        <span className="text-2xl md:text-3xl font-bold text-white">
          {value.toString().padStart(2, '0')}
        </span>
      </div>
      <span className="text-white/80 text-sm">{label}</span>
    </div>
  );

  return (
    <section ref={sectionRef} className="py-16 lg:py-24">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Big Sale */}
          <div
            className={`relative overflow-hidden rounded-2xl min-h-[400px] flex items-center transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            <img
              src="/images/hero/offer-left.jpg"
              alt="Big Sale"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#f06c4e]/90 to-[#f06c4e]/70" />
            <div className="relative z-10 p-8 md:p-12 text-white">
              <span className="inline-block bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium mb-4">
                Limited Time Offer
              </span>
              <h3 className="text-4xl md:text-5xl font-bold mb-2">Big Sale</h3>
              <p className="text-2xl md:text-3xl font-semibold mb-4">Up to 50% Off</p>
              <p className="text-white/80 mb-8 max-w-sm">
                Limited time offer on selected bestsellers. Don't miss out on these amazing deals!
              </p>

              {/* Countdown */}
              <div className="flex gap-4 mb-8">
                <TimeUnit value={timeLeft.days} label="Days" />
                <TimeUnit value={timeLeft.hours} label="Hours" />
                <TimeUnit value={timeLeft.minutes} label="Mins" />
                <TimeUnit value={timeLeft.seconds} label="Secs" />
              </div>

              <Button
                onClick={() => scrollToSection('#books')}
                className="bg-white text-[#f06c4e] hover:bg-gray-100 px-8 py-6 text-lg font-semibold rounded-full group"
              >
                Shop the Sale
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>

          {/* Special Offer */}
          <div
            className={`relative overflow-hidden rounded-2xl min-h-[400px] flex items-center transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            <img
              src="/images/hero/offer-right.jpg"
              alt="Special Offer"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#283b59]/90 to-[#283b59]/70" />
            <div className="relative z-10 p-8 md:p-12 text-white">
              <span className="inline-block bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium mb-4">
                This Week Only
              </span>
              <h3 className="text-4xl md:text-5xl font-bold mb-2">Special Offer</h3>
              <p className="text-2xl md:text-3xl font-semibold mb-4">Buy 2 Get 1 Free</p>
              <p className="text-white/80 mb-8 max-w-sm">
                On all fiction books this week. Stock up your library with our premium collection.
              </p>

              <div className="flex items-center gap-4 mb-8">
                <div className="flex -space-x-3">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white flex items-center justify-center"
                    >
                      <span className="text-lg font-bold">{i}</span>
                    </div>
                  ))}
                </div>
                <span className="text-white/80">Books for the price of 2!</span>
              </div>

              <Button
                onClick={() => scrollToSection('#books')}
                className="bg-[#f06c4e] text-white hover:bg-[#e55a3c] px-8 py-6 text-lg font-semibold rounded-full group"
              >
                View Details
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
