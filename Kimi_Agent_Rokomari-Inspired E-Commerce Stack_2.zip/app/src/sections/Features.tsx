import { useEffect, useRef, useState } from 'react';
import { Truck, RotateCcw, Shield, Headphones } from 'lucide-react';

const features = [
  {
    id: 1,
    icon: Truck,
    title: 'Free Shipping',
    description: 'On orders over $50',
    color: '#f06c4e',
  },
  {
    id: 2,
    icon: RotateCcw,
    title: 'Easy Returns',
    description: '30-day return policy',
    color: '#4caf50',
  },
  {
    id: 3,
    icon: Shield,
    title: 'Secure Payment',
    description: '100% secure checkout',
    color: '#283b59',
  },
  {
    id: 4,
    icon: Headphones,
    title: '24/7 Support',
    description: 'Always here to help',
    color: '#ff9800',
  },
];

export default function Features() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-16 lg:py-24 bg-white">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.id}
                className={`feature-card group bg-gray-50 rounded-xl p-6 flex items-center gap-4 hover:shadow-lg transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                }`}
                style={{ transitionDelay: `${index * 150 + 200}ms` }}
              >
                <div
                  className="feature-icon w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${feature.color}15` }}
                >
                  <Icon
                    className="w-7 h-7"
                    style={{ color: feature.color }}
                  />
                </div>
                <div>
                  <h3 className="font-semibold text-[#283b59] group-hover:text-[#f06c4e] transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-[#4f4f4f]">{feature.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
