import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import ProductCard from '../components/ProductCard';

const tabs = [
  { id: 'featured', name: 'Featured' },
  { id: 'bestsellers', name: 'Best Sellers' },
  { id: 'new', name: 'New Arrivals' },
  { id: 'offers', name: 'Special Offers' },
];

const books = [
  {
    id: 1,
    name: 'The Chronicles of Aetheria',
    price: 24.99,
    oldPrice: 34.99,
    image: '/images/books/book-1.jpg',
    rating: 4.8,
    discount: 29,
    category: 'Fiction',
    author: 'Elena Starweaver',
  },
  {
    id: 2,
    name: 'Great Expectations',
    price: 18.99,
    image: '/images/books/book-2.jpg',
    rating: 4.9,
    category: 'Classic',
    author: 'Charles Dickens',
  },
  {
    id: 3,
    name: 'The Silent Echoes',
    price: 22.99,
    oldPrice: 28.99,
    image: '/images/books/book-3.jpg',
    rating: 4.6,
    discount: 21,
    category: 'Mystery',
    author: 'Ava Chen',
  },
  {
    id: 4,
    name: 'The Silent Anomaly',
    price: 19.99,
    image: '/images/books/book-4.jpg',
    rating: 4.7,
    category: 'Thriller',
    author: 'Caleb Blackwood',
  },
  {
    id: 5,
    name: 'Whispered Dreams',
    price: 16.99,
    oldPrice: 21.99,
    image: '/images/books/book-5.jpg',
    rating: 4.5,
    discount: 23,
    category: 'Romance',
    author: 'Isabella Marie',
  },
  {
    id: 6,
    name: 'Neo-Genesis',
    price: 27.99,
    image: '/images/books/book-6.jpg',
    rating: 4.8,
    category: 'Sci-Fi',
    author: 'Aurora Vance',
  },
];

const babyProducts = [
  {
    id: 101,
    name: 'Cute Animal Onesie',
    price: 14.99,
    oldPrice: 19.99,
    image: '/images/baby/baby-1.jpg',
    rating: 4.9,
    discount: 25,
    category: 'Baby Clothing',
  },
  {
    id: 102,
    name: 'Soft Plush Teddy Bear',
    price: 24.99,
    image: '/images/baby/baby-2.jpg',
    rating: 4.8,
    category: 'Toys',
  },
  {
    id: 103,
    name: 'Colorful Baby Rattle',
    price: 9.99,
    oldPrice: 12.99,
    image: '/images/baby/baby-3.jpg',
    rating: 4.7,
    discount: 23,
    category: 'Toys',
  },
  {
    id: 104,
    name: 'Soft Baby Blanket',
    price: 29.99,
    image: '/images/baby/baby-4.jpg',
    rating: 4.9,
    category: 'Essentials',
  },
];

const leatherProducts = [
  {
    id: 201,
    name: 'Premium Leather Wallet',
    price: 49.99,
    oldPrice: 69.99,
    image: '/images/leather/leather-1.jpg',
    rating: 4.8,
    discount: 29,
    category: 'Accessories',
  },
  {
    id: 202,
    name: 'Elegant Leather Handbag',
    price: 149.99,
    image: '/images/leather/leather-2.jpg',
    rating: 4.9,
    category: 'Bags',
  },
  {
    id: 203,
    name: 'Classic Leather Belt',
    price: 39.99,
    oldPrice: 49.99,
    image: '/images/leather/leather-3.jpg',
    rating: 4.7,
    discount: 20,
    category: 'Accessories',
  },
  {
    id: 204,
    name: 'Leather Watch Strap',
    price: 29.99,
    image: '/images/leather/leather-4.jpg',
    rating: 4.6,
    category: 'Accessories',
  },
];

interface Product {
  id: number;
  name: string;
  price: number;
  oldPrice?: number;
  image: string;
  rating: number;
  discount?: number;
  category: string;
  author?: string;
}

interface ProductsSectionProps {
  id?: string;
  title: string;
  subtitle?: string;
  products: Product[];
  showTabs?: boolean;
}

export default function Products({
  id = 'products',
  title,
  subtitle,
  products: customProducts,
  showTabs = true,
}: ProductsSectionProps) {
  const [activeTab, setActiveTab] = useState('featured');
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 320;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  const getProducts = () => {
    if (customProducts) return customProducts;
    
    switch (activeTab) {
      case 'bestsellers':
        return books.slice(0, 4);
      case 'new':
        return books.slice(2, 6);
      case 'offers':
        return books.filter((b) => b.discount);
      default:
        return books;
    }
  };

  const displayProducts = getProducts();

  return (
    <section ref={sectionRef} id={id} className="py-16 lg:py-24 bg-gray-50">
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`flex flex-col md:flex-row md:items-end md:justify-between mb-10 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div>
            <h2 className="section-title text-3xl lg:text-4xl font-bold text-[#283b59] mb-2">
              {title}
            </h2>
            {subtitle && (
              <p className="text-[#4f4f4f]">{subtitle}</p>
            )}
          </div>

          {showTabs && (
            <div className="flex gap-6 mt-4 md:mt-0">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`text-sm font-medium pb-2 transition-colors relative ${
                    activeTab === tab.id
                      ? 'text-[#f06c4e] tab-active'
                      : 'text-[#4f4f4f] hover:text-[#f06c4e]'
                  }`}
                >
                  {tab.name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Products Container */}
        <div className="relative">
          {/* Navigation Buttons */}
          <button
            onClick={() => scroll('left')}
            className="absolute -left-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-[#f06c4e] hover:text-white transition-all duration-300 hidden lg:flex"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="absolute -right-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-[#f06c4e] hover:text-white transition-all duration-300 hidden lg:flex"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Products Grid/Scroll */}
          <div
            ref={scrollContainerRef}
            className="horizontal-scroll flex gap-6 overflow-x-auto pb-4 lg:grid lg:grid-cols-4 lg:overflow-visible"
          >
            {displayProducts.map((product, index) => (
              <div
                key={product.id}
                className={`flex-shrink-0 w-[280px] lg:w-auto transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                }`}
                style={{ transitionDelay: `${index * 100 + 300}ms` }}
              >
                <ProductCard {...product} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export { books, babyProducts, leatherProducts };
