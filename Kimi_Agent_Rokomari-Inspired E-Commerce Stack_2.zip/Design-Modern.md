# Modern E-Commerce Platform - Design Specification

## Overview
A cutting-edge e-commerce platform with hyper-modern UI/UX, featuring fluid animations, micro-interactions, and a complete full-stack architecture.

---

## Design System

### Color Palette
```css
--primary: #6366f1;           /* Indigo 500 */
--primary-dark: #4f46e5;      /* Indigo 600 */
--primary-light: #818cf8;     /* Indigo 400 */
--secondary: #ec4899;         /* Pink 500 */
--accent: #f59e0b;            /* Amber 500 */
--success: #10b981;           /* Emerald 500 */
--warning: #f97316;           /* Orange 500 */
--error: #ef4444;             /* Red 500 */
--background: #0f0f23;        /* Deep dark blue-black */
--surface: #1a1a2e;           /* Card surface */
--surface-light: #252542;     /* Elevated surface */
--text-primary: #ffffff;
--text-secondary: #a1a1aa;
--text-muted: #71717a;
--border: #27273a;
--gradient-start: #6366f1;
--gradient-end: #ec4899;
```

### Typography
- **Primary Font**: Inter (Google Fonts)
- **Display Font**: Space Grotesk for headings
- **Code Font**: JetBrains Mono

### Spacing System
- Base unit: 4px
- Scale: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128

---

## Animation System

### 1. Page Load Sequence
```
Duration: 1.2s total
Easing: cubic-bezier(0.16, 1, 0.3, 1)

1. Background gradient fade (0-400ms)
2. Logo reveal with scale (200-600ms)
3. Navigation items stagger (400-800ms, 80ms delay each)
4. Hero content cascade (600-1200ms)
5. Floating elements start (800ms+)
```

### 2. Scroll Animations (GSAP ScrollTrigger)
```
Trigger: Element enters viewport (20% threshold)

- Fade up: y: 60px → 0, opacity: 0 → 1
- Scale in: scale: 0.9 → 1, opacity: 0 → 1
- Slide left: x: -100px → 0, opacity: 0 → 1
- Slide right: x: 100px → 0, opacity: 0 → 1
- Rotate in: rotateY: -15deg → 0, opacity: 0 → 1

Stagger: 100ms between sibling elements
```

### 3. Micro-interactions

#### Button Hover
```
Duration: 300ms
Easing: cubic-bezier(0.34, 1.56, 0.64, 1)

- Scale: 1 → 1.05
- Background: Gradient shift
- Shadow: 0 0 0 → 0 10px 40px rgba(99, 102, 241, 0.3)
- Icon: translateX(0) → translateX(4px)
```

#### Card Hover
```
Duration: 400ms
Easing: cubic-bezier(0.16, 1, 0.3, 1)

- Transform: translateY(0) → translateY(-12px)
- Scale: 1 → 1.02
- Shadow: 0 4px 20px rgba(0,0,0,0.2) → 0 20px 60px rgba(99, 102, 241, 0.2)
- Image: scale(1) → scale(1.1)
- Border: opacity 0 → 1 (gradient border)
```

#### Magnetic Cursor Effect
```
On elements with .magnetic class:
- Track mouse position relative to element center
- Apply transform: translate(x * 0.3, y * 0.3)
- Spring physics for smooth return
```

### 4. Product Gallery
```
3D Carousel:
- Perspective: 1000px
- Active slide: translateZ(100px), scale(1)
- Side slides: rotateY(±45deg), translateZ(-100px), scale(0.8)
- Transition: 600ms cubic-bezier(0.16, 1, 0.3, 1)
```

### 5. Loading States
```
Skeleton Loading:
- Shimmer animation: background-position shift
- Duration: 1.5s infinite
- Gradient: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)

Spinner:
- Rotating gradient ring
- Duration: 1s linear infinite
```

### 6. Page Transitions (Framer Motion)
```
Exit: opacity 1 → 0, y: 0 → -20px (200ms)
Enter: opacity 0 → 1, y: 20px → 0 (400ms)
```

---

## Component Specifications

### 1. Glass Morphism Cards
```css
.glass-card {
  background: rgba(26, 26, 46, 0.7);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 24px;
}
```

### 2. Gradient Buttons
```css
.btn-gradient {
  background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%);
  position: relative;
  overflow: hidden;
}

.btn-gradient::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #ec4899 0%, #6366f1 100%);
  opacity: 0;
  transition: opacity 0.3s;
}

.btn-gradient:hover::before {
  opacity: 1;
}
```

### 3. Animated Borders
```css
.animated-border {
  position: relative;
  background: var(--surface);
  border-radius: 16px;
}

.animated-border::before {
  content: '';
  position: absolute;
  inset: -2px;
  border-radius: 18px;
  background: linear-gradient(45deg, #6366f1, #ec4899, #f59e0b, #6366f1);
  background-size: 400% 400%;
  animation: gradient-rotate 3s ease infinite;
  z-index: -1;
}

@keyframes gradient-rotate {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
```

### 4. Neon Glow Effects
```css
.neon-glow {
  box-shadow: 
    0 0 5px rgba(99, 102, 241, 0.5),
    0 0 20px rgba(99, 102, 241, 0.3),
    0 0 40px rgba(99, 102, 241, 0.2);
}
```

---

## Layout Structure

### Header
- Fixed position with scroll-aware hide/show
- Glass morphism effect on scroll
- Logo with animated gradient text
- Navigation with hover underline animation
- Cart icon with bounce animation on add
- User avatar with dropdown

### Hero Section
- Full viewport height
- Animated gradient mesh background
- 3D floating product showcase
- Typewriter effect for headline
- Parallax scroll layers

### Product Grid
- Masonry layout option
- Infinite scroll with skeleton loading
- Quick view modal with 3D product rotation
- Filter sidebar with animated checkboxes
- Sort dropdown with smooth transitions

### Product Detail Page
- Image gallery with zoom and pan
- 360° product view option
- Color/variant selector with morphing animation
- Size guide with interactive chart
- Add to cart with success animation
- Related products carousel

### Cart Drawer
- Slide in from right
- Item list with swipe-to-delete
- Quantity stepper with haptic feedback
- Promo code input with validation animation
- Checkout button with pulse effect

### Checkout Flow
- Multi-step progress indicator
- Form fields with floating labels
- Credit card input with visual validation
- Order summary with item animations
- Success page with confetti effect

---

## Advanced Features

### 1. Real-time Features
- Live search with debounced API calls
- Real-time inventory updates
- Live chat support widget
- Notification system with toast messages

### 2. AI-Powered Features
- Smart product recommendations
- Visual search (upload image)
- Chatbot for customer support
- Personalized homepage

### 3. Accessibility
- Keyboard navigation support
- Screen reader optimized
- Reduced motion preference support
- High contrast mode
- Focus indicators

### 4. Performance
- Lazy loading for images
- Virtual scrolling for long lists
- Code splitting by route
- Service worker for offline support
- Image optimization (WebP, responsive)

---

## Backend Architecture

### API Structure
```
/api/v1/
  ├── auth/
  │   ├── POST /register
  │   ├── POST /login
  │   ├── POST /logout
  │   ├── POST /refresh
  │   └── POST /forgot-password
  ├── users/
  │   ├── GET /me
  │   ├── PUT /me
  │   ├── GET /orders
  │   └── PUT /addresses
  ├── products/
  │   ├── GET /
  │   ├── GET /:id
  │   ├── GET /:id/reviews
  │   └── POST /:id/reviews (auth)
  ├── categories/
  │   ├── GET /
  │   └── GET /:id/products
  ├── cart/
  │   ├── GET /
  │   ├── POST /items
  │   ├── PUT /items/:id
  │   └── DELETE /items/:id
  ├── orders/
  │   ├── POST /
  │   ├── GET /
  │   └── GET /:id
  ├── wishlist/
  │   ├── GET /
  │   ├── POST /
  │   └── DELETE /:id
  └── search/
      └── GET /?q=&filters
```

### Database Schema
```sql
-- Users
users (id, email, password_hash, first_name, last_name, avatar, role, created_at)
addresses (id, user_id, type, street, city, state, zip, country, is_default)

-- Products
products (id, name, slug, description, price, compare_price, sku, inventory, category_id, images, attributes, rating_avg, review_count, created_at)
categories (id, name, slug, parent_id, image, description)
product_variants (id, product_id, name, sku, price, inventory, attributes)

-- Reviews
reviews (id, product_id, user_id, rating, title, content, images, helpful_count, created_at)

-- Cart
carts (id, user_id, session_id, created_at)
cart_items (id, cart_id, product_id, variant_id, quantity)

-- Orders
orders (id, user_id, status, total, subtotal, tax, shipping, discount, shipping_address, billing_address, payment_method, created_at)
order_items (id, order_id, product_id, variant_id, quantity, price)
order_tracking (id, order_id, status, location, timestamp)

-- Wishlist
wishlists (id, user_id, product_id, created_at)

-- Coupons
coupons (id, code, type, value, min_order, max_uses, used_count, expires_at)
```

---

## Animation Libraries

### Primary
- **GSAP + ScrollTrigger** - Complex scroll animations, timelines
- **Framer Motion** - React component animations, gestures, AnimatePresence
- **Lottie** - Complex icon animations

### Secondary
- **React Spring** - Physics-based animations
- **Three.js / React Three Fiber** - 3D product viewer
- **Canvas Confetti** - Celebration effects

---

## Responsive Breakpoints

```
Mobile: < 640px
Tablet: 640px - 1024px
Desktop: 1024px - 1440px
Large: > 1440px
```

---

## Dark Mode (Default)
- Deep navy background (#0f0f23)
- Purple/pink gradient accents
- Glass morphism cards
- Neon glow effects
- High contrast text
